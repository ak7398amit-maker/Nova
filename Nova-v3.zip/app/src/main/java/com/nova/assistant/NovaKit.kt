package com.nova.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class VoiceItem(val name: String, val id: String)

/** Saari settings ek jagah: naam, API keys, awaazein. */
object Cfg {
    private fun sp(c: Context) = c.getSharedPreferences("nova", Context.MODE_PRIVATE)

    fun userName(c: Context): String = (sp(c).getString("user_name", "") ?: "").trim()
    fun setUserName(c: Context, v: String) {
        sp(c).edit().putString("user_name", v.trim()).apply()
    }

    fun elKey(c: Context): String = (sp(c).getString("el_key", "") ?: "").trim()
    fun setElKey(c: Context, v: String) {
        sp(c).edit().putString("el_key", v.trim()).apply()
    }

    fun geminiKey(c: Context): String = (sp(c).getString("g_key", "") ?: "").trim()
    fun setGeminiKey(c: Context, v: String) {
        sp(c).edit().putString("g_key", v.trim()).apply()
    }

    fun geminiModel(c: Context): String {
        val m = (sp(c).getString("g_model", "") ?: "").trim()
        return if (m.isEmpty()) "gemini-3.8-flash" else m
    }

    fun setGeminiModel(c: Context, v: String) {
        sp(c).edit().putString("g_model", v.trim()).apply()
    }

    fun voices(c: Context): MutableList<VoiceItem> {
        val out = ArrayList<VoiceItem>()
        try {
            val arr = JSONArray(sp(c).getString("voices", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(VoiceItem(o.optString("n"), o.optString("id")))
            }
        } catch (e: Exception) {
        }
        // purane version ki ek voice ID ko naye list mein le aao
        if (out.isEmpty()) {
            val legacy = (sp(c).getString("el_voice", "") ?: "").trim()
            if (legacy.isNotEmpty()) {
                out.add(VoiceItem("Meri awaaz", legacy))
                saveVoices(c, out)
                setActiveIndex(c, 0)
                sp(c).edit().remove("el_voice").apply()
            }
        }
        return out
    }

    fun saveVoices(c: Context, list: List<VoiceItem>) {
        val arr = JSONArray()
        for (v in list) arr.put(JSONObject().put("n", v.name).put("id", v.id))
        sp(c).edit().putString("voices", arr.toString()).apply()
    }

    /** -1 matlab phone ki apni awaaz. */
    fun activeIndex(c: Context): Int = sp(c).getInt("voice_idx", -1)

    fun setActiveIndex(c: Context, i: Int) {
        sp(c).edit().putInt("voice_idx", i).apply()
    }

    fun activeVoice(c: Context): VoiceItem? {
        val l = voices(c)
        val i = activeIndex(c)
        return if (i in l.indices) l[i] else null
    }
}

/** ElevenLabs se awaaz banana. */
object Eleven {
    class Result(val file: File?, val error: String?)

    fun hint(code: Int): String = when (code) {
        401 -> "API key galat hai."
        402 -> "Ye voice free plan par API se nahi chalti."
        404 -> "Voice ID galat hai."
        422 -> "Voice ID ya request galat hai."
        429 -> "Limit ya credits khatam."
        else -> "Error $code."
    }

    fun synth(c: Context, text: String, voiceId: String, key: String, tag: String): Result {
        return try {
            val url = URL(
                "https://api.elevenlabs.io/v1/text-to-speech/" +
                    URLEncoder.encode(voiceId, "UTF-8") + "?output_format=mp3_44100_64"
            )
            val con = url.openConnection() as HttpURLConnection
            con.requestMethod = "POST"
            con.connectTimeout = 8000
            con.readTimeout = 25000
            con.doOutput = true
            con.setRequestProperty("xi-api-key", key)
            con.setRequestProperty("Content-Type", "application/json")
            con.setRequestProperty("Accept", "audio/mpeg")
            val body = JSONObject()
                .put("text", text)
                .put("model_id", "eleven_flash_v2_5")
                .toString()
            con.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = con.responseCode
            if (code != 200) {
                Result(null, hint(code))
            } else {
                val f = File(c.cacheDir, "nova_$tag.mp3")
                con.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                Result(f, null)
            }
        } catch (e: Exception) {
            Result(null, "ElevenLabs se connect nahi hua (internet?)")
        }
    }
}

/** Gemini se sawal ka jawab. */
object Gemini {
    class Result(val text: String?, val error: String?)

    private val fallbacks = listOf(
        "gemini-3.8-flash", "gemini-3.6-flash", "gemini-3.5-flash-lite", "gemini-2.5-flash"
    )

    private fun systemPrompt(c: Context): String {
        val name = Cfg.userName(c)
        val now = SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale.ENGLISH).format(Date())
        val who = if (name.isNotEmpty()) "Tumhare user ka naam $name hai. Kabhi kabhi naam lekar bulao, har vakya mein nahi. "
        else ""
        return "Tum Nova ho, ek voice assistant jo user ke phone par chalta hai aur sabke sawalon ke jawab deta hai. " + who +
            "Jis tarah user bole (Hindi, Hinglish ya English), usi tarah Roman script mein jawab do. " +
            "Jawab chhota rakho, zyada se zyada 2 se 3 vakya, kyunki tumhara jawab bolkar sunaya jayega. " +
            "Markdown, bullet, emoji, links aur star (*) mat use karo. " +
            "Sach batao, agar pata na ho to saaf bol do. Abhi ki tareekh aur samay: $now."
    }

    /** history: (role, text) jahan role "user" ya "model". */
    fun ask(c: Context, history: List<Pair<String, String>>, question: String): Result {
        val key = Cfg.geminiKey(c)
        if (key.isEmpty()) return Result(null, "Gemini API key nahi hai.")
        val contents = JSONArray()
        for ((r, t) in history) {
            contents.put(
                JSONObject().put("role", r)
                    .put("parts", JSONArray().put(JSONObject().put("text", t)))
            )
        }
        contents.put(
            JSONObject().put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", question)))
        )
        val body = JSONObject()
            .put(
                "system_instruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt(c))))
            )
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", 800).put("temperature", 0.7))
            .toString()

        val tried = LinkedHashSet<String>()
        tried.add(Cfg.geminiModel(c))
        tried.addAll(fallbacks)
        var lastErr = "Gemini ne jawab nahi diya."
        for (model in tried) {
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                val con = url.openConnection() as HttpURLConnection
                con.requestMethod = "POST"
                con.connectTimeout = 8000
                con.readTimeout = 30000
                con.doOutput = true
                con.setRequestProperty("x-goog-api-key", key)
                con.setRequestProperty("Content-Type", "application/json")
                con.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val code = con.responseCode
                if (code == 200) {
                    val txt = con.inputStream.bufferedReader().use { it.readText() }
                    val j = JSONObject(txt)
                    val cands = j.optJSONArray("candidates")
                    if (cands == null || cands.length() == 0) {
                        return Result(null, "Gemini ne is sawal ka jawab dene se mana kiya.")
                    }
                    val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
                    val sb = StringBuilder()
                    if (parts != null) {
                        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                    }
                    val out = clean(sb.toString())
                    return if (out.isEmpty()) Result(null, "Gemini ka jawab khali aaya.") else Result(out, null)
                }
                val err = try {
                    con.errorStream?.bufferedReader()?.use { it.readText() } ?: ""
                } catch (e: Exception) {
                    ""
                }
                lastErr = when (code) {
                    400 -> if (err.contains("API key", true)) "Gemini API key galat hai." else "Gemini request galat ($code)."
                    401, 403 -> "Gemini API key galat hai ya allowed nahi hai."
                    429 -> "Gemini ki limit khatam, thodi der baad try karo."
                    else -> "Gemini error $code."
                }
                // model hi nahi mila to agla model try karo, baaki errors par ruk jao
                if (code != 404) return Result(null, lastErr)
                lastErr = "Gemini model nahi mila: $model."
            } catch (e: Exception) {
                return Result(null, "Gemini se connect nahi hua (internet?)")
            }
        }
        return Result(null, lastErr)
    }

    private fun clean(s: String): String =
        s.replace("*", "").replace("#", "").replace("`", "").replace(Regex("\\s+"), " ").trim()
}
