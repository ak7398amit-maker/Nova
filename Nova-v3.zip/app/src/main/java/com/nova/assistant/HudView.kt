package com.nova.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.BatteryManager
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** JARVIS jaisa neela HUD: arc reactor orb, ghoomti rings, waveform, clock aur battery. */
class HudView(context: Context) : View(context) {

    private val cyan = 0xFF00E5FF.toInt()
    private val deep = 0xFF020B14.toInt()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t0 = System.nanoTime()
    private var lvl = 0f
    private val timeFmt = SimpleDateFormat("hh:mm:ss a", Locale.getDefault())
    private var batt = 0
    private var battAt = 0L
    private val d = resources.displayMetrics.density
    private val mono = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    private fun clip(s: String, n: Int): String = if (s.length > n) s.take(n - 1) + "…" else s

    private fun box(c: Canvas, l: Float, t: Float, r: Float, b: Float, text: String) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f * d
        p.color = cyan
        p.alpha = 150
        c.drawRoundRect(l, t, r, b, 6f * d, 6f * d, p)
        p.style = Paint.Style.FILL
        p.alpha = 255
        p.textSize = 12f * d
        p.letterSpacing = 0.1f
        p.textAlign = Paint.Align.CENTER
        c.drawText(text, (l + r) / 2f, (t + b) / 2f + 4f * d, p)
    }

    private fun corner(c: Canvas, x: Float, y: Float, dx: Float, dy: Float) {
        val len = 22f * d
        c.drawLine(x, y, x + dx * len, y, p)
        c.drawLine(x, y, x, y + dy * len, p)
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val t = (System.nanoTime() - t0) / 1e9f
        val st = NovaService.state
        val live = NovaService.running

        val target = when (st) {
            "SPEAKING" -> 0.45f + 0.4f * abs(sin(t * 9f))
            "LISTENING" -> NovaService.level
            "PROCESSING" -> 0.25f + 0.1f * sin(t * 6f)
            else -> 0.05f
        }
        lvl += (target - lvl) * 0.18f

        c.drawColor(deep)

        // halka grid
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1f
        p.color = cyan
        p.alpha = 14
        var gx = 0f
        while (gx < w) {
            c.drawLine(gx, 0f, gx, h, p)
            gx += 36f * d
        }
        var gy = 0f
        while (gy < h) {
            c.drawLine(0f, gy, w, gy, p)
            gy += 36f * d
        }

        // kone ke brackets
        p.strokeWidth = 2f * d
        p.alpha = 200
        corner(c, 12f * d, 12f * d, 1f, 1f)
        corner(c, w - 12f * d, 12f * d, -1f, 1f)
        corner(c, 12f * d, h - 12f * d, 1f, -1f)
        corner(c, w - 12f * d, h - 12f * d, -1f, -1f)

        // title
        p.style = Paint.Style.FILL
        p.typeface = mono
        p.textAlign = Paint.Align.CENTER
        p.color = cyan
        p.alpha = 255
        p.textSize = 30f * d
        p.letterSpacing = 0.55f
        c.drawText("NOVA", w / 2f, 58f * d, p)

        val status = when {
            !live -> "OFFLINE  -  START dabayein"
            st == "LISTENING" -> "LISTENING..."
            st == "PROCESSING" -> "PROCESSING..."
            st == "SPEAKING" -> "SPEAKING..."
            else -> "I'M ONLINE, SIR"
        }
        p.textSize = 11f * d
        p.letterSpacing = 0.2f
        p.alpha = 190
        c.drawText(status, w / 2f, 78f * d, p)
        p.alpha = 255

        // clock + battery
        val now = System.currentTimeMillis()
        if (now - battAt > 2000) {
            battAt = now
            try {
                val bm = context.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                batt = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            } catch (e: Exception) {
            }
        }
        val bTop = 96f * d
        val bBot = bTop + 30f * d
        val gap = 10f * d
        val left = 20f * d
        val right = w - 20f * d
        val mid = (left + right) / 2f
        box(c, left, bTop, mid - gap / 2f, bBot, timeFmt.format(Date(now)))
        box(c, mid + gap / 2f, bTop, right, bBot, "$batt%")

        // orb
        val cx = w / 2f
        val cy = h * 0.5f + 20f * d
        val r0 = min(w, h) * 0.13f

        for (i in 0..3) {
            val rr = r0 * (1.55f + 0.38f * i) * (1f + 0.02f * lvl)
            val rot = t * (28f + 14f * i) * (if (i % 2 == 0) 1f else -1f)
            p.style = Paint.Style.STROKE
            p.strokeWidth = (3f - i * 0.5f) * d
            p.color = cyan
            p.alpha = 235 - i * 40
            val rect = RectF(cx - rr, cy - rr, cx + rr, cy + rr)
            for (k in 0..2) {
                c.drawArc(rect, rot + k * 120f, 75f - i * 9f, false, p)
            }
        }

        val rr = r0 * (1f + 0.22f * lvl + 0.025f * sin(t * 2f))
        p.style = Paint.Style.FILL
        p.alpha = 255
        p.shader = RadialGradient(
            cx, cy, rr,
            intArrayOf(0xFFB8F6FF.toInt(), 0xFF00B8D4.toInt(), 0x3300E5FF),
            floatArrayOf(0f, 0.6f, 1f),
            Shader.TileMode.CLAMP
        )
        c.drawCircle(cx, cy, rr, p)
        p.shader = null

        // glow ring
        p.style = Paint.Style.STROKE
        p.color = cyan
        for (i in 3 downTo 0) {
            p.alpha = if (i == 0) 255 else 30
            p.strokeWidth = 2.5f * d + i * 3f * d
            c.drawCircle(cx, cy, rr, p)
        }

        // beech ka triangle
        c.save()
        c.rotate(t * 20f, cx, cy)
        val path = Path()
        val tr = rr * 0.55f
        for (k in 0..2) {
            val a = Math.toRadians((k * 120 - 90).toDouble())
            val x = cx + tr * cos(a).toFloat()
            val y = cy + tr * sin(a).toFloat()
            if (k == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        p.color = deep
        p.alpha = 255
        p.strokeWidth = 3f * d
        c.drawPath(path, p)
        c.restore()

        // waveform
        val y0 = cy + r0 * 3.35f
        val n = 33
        val bw = w * 0.8f / n
        val x0 = w * 0.1f
        p.style = Paint.Style.FILL
        p.color = cyan
        p.alpha = 210
        for (i in 0 until n) {
            val env = 0.55f + 0.45f * sin(i * 0.2f)
            val amp = (0.12f + 0.88f * lvl) * abs(sin(i * 0.55f + t * 7f)) * env
            val bh = (3f + amp * 40f) * d
            c.drawRect(x0 + i * bw + bw * 0.25f, y0 - bh / 2f, x0 + i * bw + bw * 0.75f, y0 + bh / 2f, p)
        }

        // jo suna wo likha hua
        p.alpha = 255
        p.color = 0xFFFFFFFF.toInt()
        p.textSize = 15f * d
        p.letterSpacing = 0.05f
        p.textAlign = Paint.Align.CENTER
        val heard = NovaService.lastHeard
        if (heard.isNotEmpty()) {
            c.drawText(clip(heard.uppercase(Locale.getDefault()), 34), w / 2f, y0 + 46f * d, p)
        }

        postInvalidateOnAnimation()
    }
}
