package com.nova.assistant

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.text.InputType
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.ScrollView
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val d get() = resources.displayMetrics.density
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var hud: HudView
    private lateinit var logView: TextView
    private lateinit var btnMain: Button
    private lateinit var btnPerm: Button
    private lateinit var btnOverlay: Button
    private lateinit var btnAccess: Button
    private lateinit var btnBattery: Button
    private lateinit var btnLang: Button

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(0xFF020B14.toInt())

        hud = HudView(this)
        root.addView(hud, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        logView = TextView(this)
        logView.typeface = Typeface.MONOSPACE
        logView.textSize = 11f
        logView.setTextColor(0xFF7FE9FF.toInt())
        logView.minLines = 4
        logView.setPadding((16 * d).toInt(), (6 * d).toInt(), (16 * d).toInt(), (6 * d).toInt())
        root.addView(
            logView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        val panel = LinearLayout(this)
        panel.orientation = LinearLayout.VERTICAL
        panel.setPadding((12 * d).toInt(), 0, (12 * d).toInt(), (14 * d).toInt())

        btnMain = neon("START NOVA", true)
        btnMain.setOnClickListener { toggleNova() }
        panel.addView(btnMain, row1())

        val r1 = rowOf()
        btnPerm = neon("PERMS")
        btnPerm.setOnClickListener { requestPermissions(perms(), 1) }
        btnOverlay = neon("OVERLAY")
        btnOverlay.setOnClickListener {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btnAccess = neon("ACCESS")
        btnAccess.setOnClickListener { accessHelp() }
        btnBattery = neon("BATTERY")
        btnBattery.setOnClickListener {
            try {
                startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        for (b in listOf(btnPerm, btnOverlay, btnAccess, btnBattery)) r1.addView(b, cell())
        panel.addView(r1, rowLp())

        val r2 = rowOf()
        btnLang = neon("LANG")
        btnLang.setOnClickListener { toggleLang() }
        val btnVoice = neon("VOICES")
        btnVoice.setOnClickListener { startActivity(Intent(this, VoicesActivity::class.java)) }
        val btnProfile = neon("PROFILE")
        btnProfile.setOnClickListener { profileDialog(false) }
        val btnHelp = neon("COMMANDS")
        btnHelp.setOnClickListener { showCommands() }
        r2.addView(btnLang, cell())
        r2.addView(btnVoice, cell())
        r2.addView(btnProfile, cell())
        r2.addView(btnHelp, cell())
        panel.addView(r2, rowLp())

        root.addView(
            panel,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        setContentView(root)

        val sp = getSharedPreferences("nova", Context.MODE_PRIVATE)
        if (Cfg.userName(this).isEmpty() && !sp.getBoolean("asked_name", false)) {
            sp.edit().putBoolean("asked_name", true).apply()
            ui.post { profileDialog(true) }
        }
    }

    override fun onResume() {
        super.onResume()
        NovaService.onLog = { runOnUiThread { logView.text = NovaService.logText() } }
        logView.text = NovaService.logText()
        ui.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        NovaService.onLog = null
        ui.removeCallbacks(ticker)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        refresh()
    }

    // ---------- helpers ----------

    private fun perms(): Array<String> {
        val l = arrayListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.ANSWER_PHONE_CALLS
        )
        if (Build.VERSION.SDK_INT >= 33) l.add(Manifest.permission.POST_NOTIFICATIONS)
        return l.toTypedArray()
    }

    private fun hasAllPerms(): Boolean =
        perms().all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }

    private fun refresh() {
        btnMain.text = if (NovaService.running) "STOP NOVA" else "START NOVA"
        btnPerm.text = (if (hasAllPerms()) "✓ " else "") + "PERMS"
        btnOverlay.text = (if (Settings.canDrawOverlays(this)) "✓ " else "") + "OVERLAY"
        btnAccess.text = (if (NovaAccessibility.instance != null) "✓ " else "") + "ACCESS"
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        btnBattery.text = (if (pm.isIgnoringBatteryOptimizations(packageName)) "✓ " else "") + "BATTERY"
        val lang = getSharedPreferences("nova", Context.MODE_PRIVATE).getString("lang", "hi-IN")
        btnLang.text = "LANG: " + (if (lang == "en-IN") "ENGLISH" else "HINDI")
    }

    private fun toggleNova() {
        if (NovaService.running) {
            stopService(Intent(this, NovaService::class.java))
        } else {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(perms(), 1)
                return
            }
            startForegroundService(Intent(this, NovaService::class.java))
        }
        ui.postDelayed({ refresh() }, 600)
    }

    private fun toggleLang() {
        val sp = getSharedPreferences("nova", Context.MODE_PRIVATE)
        val cur = sp.getString("lang", "hi-IN")
        sp.edit().putString("lang", if (cur == "hi-IN") "en-IN" else "hi-IN").apply()
        refresh()
    }

    private fun label(t: String): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = 12f
        v.setPadding(0, (12 * d).toInt(), 0, 0)
        return v
    }

    private fun field(hint: String, value: String, secret: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setSingleLine(true)
        if (secret) {
            e.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
        }
        e.setText(value)
        return e
    }

    /** Naam aur API keys. firstTime = pehli baar naam poochhne ke liye. */
    private fun profileDialog(firstTime: Boolean) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val pad = (20 * d).toInt()
        box.setPadding(pad, (4 * d).toInt(), pad, 0)

        box.addView(label("Aapka naam (Nova isi naam se bulayegi)"))
        val nameIn = field("Jaise: Amit", Cfg.userName(this))
        box.addView(nameIn)

        box.addView(label("Gemini API key (sawalon ke jawab ke liye)"))
        val gIn = field("Gemini API key", Cfg.geminiKey(this), true)
        box.addView(gIn)
        val gh = TextView(this)
        gh.text = "Free key: aistudio.google.com/apikey"
        gh.textSize = 11f
        box.addView(gh)

        box.addView(label("ElevenLabs API key (apni awaaz ke liye)"))
        val eIn = field("ElevenLabs API key", Cfg.elKey(this), true)
        box.addView(eIn)
        val eh = TextView(this)
        eh.text = "Awaazein VOICES button se jodiye."
        eh.textSize = 11f
        box.addView(eh)

        box.addView(label("Gemini model (khali chhodo to apne aap)"))
        val mIn = field("gemini-3.8-flash", getSharedPreferences("nova", Context.MODE_PRIVATE).getString("g_model", "") ?: "")
        box.addView(mIn)

        val scroll = ScrollView(this)
        scroll.addView(box)

        AlertDialog.Builder(this)
            .setTitle(if (firstTime) "Pehle apna naam batayein" else "Nova profile")
            .setView(scroll)
            .setPositiveButton("Save") { _, _ ->
                Cfg.setUserName(this, nameIn.text.toString())
                Cfg.setGeminiKey(this, gIn.text.toString())
                Cfg.setElKey(this, eIn.text.toString())
                Cfg.setGeminiModel(this, mIn.text.toString())
                Toast.makeText(this, "Save ho gaya.", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton(if (firstTime) "Baad mein" else "Cancel", null)
            .show()
    }

    private fun accessHelp() {
        AlertDialog.Builder(this)
            .setTitle("Accessibility chalu karein")
            .setMessage(
                "Back, home, scroll, tap aur WhatsApp message bhejne ke liye ye zaroori hai.\n\n" +
                    "1. Settings kholne ke baad Installed apps / Downloaded apps mein Nova chuniye aur use ON kijiye.\n\n" +
                    "2. Agar \"Restricted setting\" likha aaye to: phone ki Settings > Apps > Nova > upar teen dot (⋮) > \"Allow restricted settings\", phir wapas aakar ON kijiye."
            )
            .setPositiveButton("Settings kholo") { _, _ ->
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            .setNeutralButton("App info") { _, _ ->
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
            .setNegativeButton("Baad mein", null)
            .show()
    }

    private fun showCommands() {
        val msg = "Pehle \"Hey Nova\" bolein, phir command.\n\n" +
            "• Whatsapp kholo / Instagram kholo\n" +
            "• Saloni ko call karo\n" +
            "• Saloni ko WhatsApp call karo\n" +
            "• Saloni ko message bhejo ki main late hoon\n" +
            "• Torch on / off\n" +
            "• Volume badhao / kam karo / mute\n" +
            "• Gaana chalao / pause / agla\n" +
            "• YouTube par arijit singh chalao\n" +
            "• Rasta batao Connaught Place\n" +
            "• Alarm lagao subah 6 baje\n" +
            "• 10 minute ka timer\n" +
            "• Battery kitni hai / time kya hai / aaj ki date\n" +
            "• Back / Home / Recent / Notification\n" +
            "• Neeche scroll karo / agli reel\n" +
            "• Screenshot lo / screen lock karo\n" +
            "• Click Send (screen par dikh rahe button par)\n" +
            "• Call utha lo / call kaat do\n" +
            "• Google par ... search karo\n" +
            "• Kuch bhi poochho: \"Hey Nova, chand par pehla insaan kaun gaya\" (Gemini jawab dega)\n" +
            "• Mera naam Amit hai / mera naam kya hai\n" +
            "• Awaaz badlo (agli awaaz), awaaz badlo Sara\n" +
            "• Nova so jao (assistant band)"
        AlertDialog.Builder(this).setTitle("NOVA commands").setMessage(msg).setPositiveButton("OK", null).show()
    }

    private fun neon(label: String, big: Boolean = false): Button {
        val b = Button(this)
        b.text = label
        b.setTextColor(0xFF00E5FF.toInt())
        b.typeface = Typeface.MONOSPACE
        b.textSize = if (big) 16f else 10.5f
        b.setPadding(0, 0, 0, 0)
        b.stateListAnimator = null
        val g = GradientDrawable()
        g.setColor(0x2200E5FF)
        g.setStroke((1.5f * d).toInt(), 0xFF00E5FF.toInt())
        g.cornerRadius = 10f * d
        b.background = g
        b.gravity = Gravity.CENTER
        return b
    }

    private fun row1() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (54 * d).toInt())

    private fun rowOf(): LinearLayout {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        return r
    }

    private fun rowLp(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (44 * d).toInt())
        lp.topMargin = (8 * d).toInt()
        return lp
    }

    private fun cell(): LinearLayout.LayoutParams {
        val lp = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
        lp.leftMargin = (3 * d).toInt()
        lp.rightMargin = (3 * d).toInt()
        return lp
    }
}
