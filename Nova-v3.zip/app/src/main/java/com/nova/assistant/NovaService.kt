package com.nova.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.Locale

/**
 * Hands-free awaaz wali service. Hamesha sunti rehti hai, "Hey Nova" sunte hi command leti hai.
 */
class NovaService : Service(), TextToSpeech.OnInitListener {

    companion object {
        const val CHANNEL = "nova_voice"
        const val NOTIF_ID = 7
        const val ACTION_STOP = "com.nova.assistant.STOP"

        @Volatile
        var running = false

        @Volatile
        var state = "OFFLINE"

        @Volatile
        var level = 0f

        @Volatile
        var lastHeard = ""

        private val lines = ArrayList<String>()
        var onLog: (() -> Unit)? = null

        fun log(s: String) {
            synchronized(lines) {
                lines.add(s)
                while (lines.size > 6) lines.removeAt(0)
            }
            onLog?.invoke()
        }

        fun logText(): String = synchronized(lines) { lines.joinToString("\n") }

        private val WAKE = listOf("nova", "नोवा", "नॉवा", "नोबा", "novah", "noba", "नोवा")
        private val WAKE_FILLER = setOf("hey", "hi", "ok", "okay", "हे", "ओके", "हाय")
    }

    private var rec: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var router: CommandRouter
    private lateinit var audio: AudioManager
    private var speaking = false
    private var thinking = false
    private var followUp = false
    private val history = ArrayList<Pair<String, String>>()
    private var player: MediaPlayer? = null
    private var speakGen = 0
    private var armedUntil = 0L
    private var errorStreak = 0
    private var welcomed = false

    private val restartRunnable = Runnable { startListening() }
    private val speakWatchdog = Runnable { finishSpeaking() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        router = CommandRouter(this, { speak(it) }, { stopSelf() }, { askAi(it) })
        tts = TextToSpeech(this, this)
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Nova voice", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, NovaService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notif = Notification.Builder(this, CHANNEL)
            .setContentTitle("Nova sun raha hai")
            .setContentText("\"Hey Nova\" bolkar command dein")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "Band karo", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(NOTIF_ID, notif)
        }
        running = true
        state = "IDLE"
        log("NOVA: service chalu hai")
        if (ttsReady) {
            if (!welcomed) {
                welcomed = true
                speak(if (nm().isEmpty()) "Nova online hai. Hey Nova bolkar mujhe bulaiye." else "Namaste ${nm()}, Nova online hai. Hey Nova bolkar mujhe bulaiye.")
            } else {
                startListening()
            }
        }
        return START_STICKY
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val t = tts ?: return
            var r = t.setLanguage(Locale("hi", "IN"))
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                r = t.setLanguage(Locale("en", "IN"))
            }
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    handler.post { finishSpeaking() }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    handler.post { finishSpeaking() }
                }
            })
            ttsReady = true
            if (running && !welcomed) {
                welcomed = true
                speak(if (nm().isEmpty()) "Nova online hai. Hey Nova bolkar mujhe bulaiye." else "Namaste ${nm()}, Nova online hai. Hey Nova bolkar mujhe bulaiye.")
            }
        } else {
            ttsReady = false
            if (running) startListening()
        }
    }

    // ---------- bolna ----------

    private fun nm(): String = Cfg.userName(this)

    private fun speak(text: String) {
        log("NOVA: $text")
        speakGen++
        stopPlayer()
        tts?.stop()
        val v = Cfg.activeVoice(this)
        val key = Cfg.elKey(this)
        if (v != null && key.isNotEmpty() && v.id.isNotEmpty()) {
            speaking = true
            state = "SPEAKING"
            handler.removeCallbacks(restartRunnable)
            rec?.cancel()
            speakEleven(text, key, v.id)
        } else {
            speakLocal(text)
        }
    }

    /** Phone ki apni awaaz (fallback). */
    private fun speakLocal(text: String) {
        if (!ttsReady) {
            speaking = false
            state = "IDLE"
            restartSoon(300)
            return
        }
        speaking = true
        state = "SPEAKING"
        handler.removeCallbacks(restartRunnable)
        rec?.cancel()
        val result = tts?.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), "u" + System.nanoTime())
        if (result != TextToSpeech.SUCCESS) {
            finishSpeaking()
            return
        }
        handler.removeCallbacks(speakWatchdog)
        handler.postDelayed(speakWatchdog, 20000)
    }

    /** ElevenLabs ki awaaz. Kuch bhi gadbad ho to phone ki awaaz par laut aata hai. */
    private fun speakEleven(text: String, key: String, voice: String) {
        val gen = speakGen
        handler.removeCallbacks(speakWatchdog)
        handler.postDelayed(speakWatchdog, 45000)
        Thread {
            val r = Eleven.synth(this, text, voice, key, gen.toString())
            handler.post {
                if (gen != speakGen || !running) {
                    r.file?.delete()
                } else if (r.file == null) {
                    log("NOVA: ${r.error ?: "ElevenLabs error"}")
                    speakLocal(text)
                } else {
                    play(r.file)
                }
            }
        }.start()
    }

    // ---------- Gemini ----------

    /** Jo sawal phone ka kaam nahi hai, use Gemini ko bhejta hai. */
    private fun askAi(q: String) {
        if (Cfg.geminiKey(this).isEmpty()) {
            speak("Ye mujhe samajh nahi aaya. Sawalon ke jawab ke liye PROFILE mein Gemini API key daaliye.")
            return
        }
        thinking = true
        state = "PROCESSING"
        handler.removeCallbacks(restartRunnable)
        rec?.cancel()
        val snapshot = ArrayList(history)
        Thread {
            val r = Gemini.ask(this, snapshot, q)
            handler.post {
                thinking = false
                if (!running) return@post
                val t = r.text
                if (t != null) {
                    history.add(Pair("user", q))
                    history.add(Pair("model", t))
                    while (history.size > 12) history.removeAt(0)
                    followUp = true
                    speak(t)
                } else {
                    speak(r.error ?: "Jawab nahi mil paya.")
                }
            }
        }.start()
    }

    private fun play(file: File) {
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(file.absolutePath)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener {
                handler.post {
                    file.delete()
                    if (player === mp) {
                        stopPlayer()
                        finishSpeaking()
                    }
                }
            }
            mp.setOnErrorListener { _, _, _ ->
                handler.post {
                    file.delete()
                    if (player === mp) {
                        stopPlayer()
                        finishSpeaking()
                    }
                }
                true
            }
            player = mp
            mp.prepareAsync()
        } catch (e: Exception) {
            file.delete()
            finishSpeaking()
        }
    }

    private fun stopPlayer() {
        try {
            player?.reset()
        } catch (e: Exception) {
        }
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
    }

    private fun finishSpeaking() {
        handler.removeCallbacks(speakWatchdog)
        if (!speaking) return
        speaking = false
        if (followUp) {
            followUp = false
            armedUntil = System.currentTimeMillis() + 10000
        }
        if (running) {
            state = "IDLE"
            restartSoon(400)
        }
    }

    // ---------- sunna ----------

    private fun createRecognizer() {
        rec?.destroy()
        rec = null
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            log("NOVA: Speech service nahi mili. Google app update karein.")
            return
        }
        rec = SpeechRecognizer.createSpeechRecognizer(this).also {
            it.setRecognitionListener(listener)
        }
    }

    private fun restartSoon(ms: Long) {
        handler.removeCallbacks(restartRunnable)
        handler.postDelayed(restartRunnable, ms)
    }

    private fun muteBeep() {
        try {
            audio.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0)
            audio.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_MUTE, 0)
            handler.postDelayed({ unmuteBeep() }, 900)
        } catch (e: Exception) {
        }
    }

    private fun unmuteBeep() {
        try {
            audio.adjustStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_UNMUTE, 0)
            audio.adjustStreamVolume(AudioManager.STREAM_SYSTEM, AudioManager.ADJUST_UNMUTE, 0)
        } catch (e: Exception) {
        }
    }

    private fun startListening() {
        if (!running || speaking) return
        if (rec == null) createRecognizer()
        val r = rec ?: return
        val lang = getSharedPreferences("nova", Context.MODE_PRIVATE).getString("lang", "hi-IN") ?: "hi-IN"
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
        i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        try {
            muteBeep()
            state = "LISTENING"
            r.startListening(i)
        } catch (e: Exception) {
            restartSoon(1500)
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {
            level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
        }

        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
            state = "PROCESSING"
            level = 0f
        }

        override fun onError(error: Int) {
            level = 0f
            if (speaking || !running) return
            errorStreak++
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    log("NOVA: Mic ki permission chahiye.")
                    state = "OFFLINE"
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    rec?.cancel()
                    restartSoon(1200)
                }
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    state = "IDLE"
                    restartSoon(120)
                }
                else -> {
                    if (errorStreak % 4 == 0) createRecognizer()
                    restartSoon(800)
                }
            }
        }

        override fun onResults(results: Bundle?) {
            errorStreak = 0
            level = 0f
            val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            onHeard(list?.firstOrNull()?.trim() ?: "")
        }

        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    private fun onHeard(heard: String) {
        if (heard.isEmpty()) {
            restartSoon(120)
            return
        }
        val low = heard.lowercase(Locale.ROOT)

        // pichle sawal ka jawab ya "ji boliye" ke baad: bina wake word ke
        val armed = System.currentTimeMillis() < armedUntil
        if (router.awaiting != null) {
            lastHeard = heard
            log("YOU: $heard")
            state = "PROCESSING"
            router.handle(heard)
            afterCommand()
            return
        }
        if (armed) {
            armedUntil = 0
            lastHeard = heard
            log("YOU: $heard")
            state = "PROCESSING"
            router.handle(low)
            afterCommand()
            return
        }

        var idx = -1
        var len = 0
        for (w in WAKE) {
            val k = low.indexOf(w)
            if (k >= 0 && (idx < 0 || k < idx)) {
                idx = k
                len = w.length
            }
        }
        if (idx < 0) {
            state = "IDLE"
            restartSoon(100)
            return
        }
        val after = low.substring(idx + len).trim().trimStart(',', ' ')
        val before = low.substring(0, idx).split(" ").filter { it.isNotEmpty() && it !in WAKE_FILLER }
            .joinToString(" ")
        val cmd = if (after.isNotEmpty()) after else before
        lastHeard = heard
        log("YOU: $heard")
        if (cmd.isEmpty()) {
            armedUntil = System.currentTimeMillis() + 15000
            speak(if (nm().isEmpty()) "Ji, boliye." else "Ji ${nm()}, boliye.")
            return
        }
        state = "PROCESSING"
        router.handle(cmd)
        afterCommand()
    }

    private fun afterCommand() {
        if (!speaking && !thinking) {
            state = "IDLE"
            restartSoon(500)
        }
    }

    override fun onDestroy() {
        running = false
        state = "OFFLINE"
        level = 0f
        handler.removeCallbacksAndMessages(null)
        speakGen++
        thinking = false
        stopPlayer()
        unmuteBeep()
        rec?.destroy()
        rec = null
        tts?.stop()
        tts?.shutdown()
        tts = null
        log("NOVA: band ho gaya")
        super.onDestroy()
    }
}
