package com.nova.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.KeyEvent
import java.util.Calendar
import java.util.Locale

/**
 * Bole gaye text ko samajhkar phone par kaam karta hai.
 * Hindi (Devanagari) aur Hinglish (Roman) dono chalte hain.
 */
class CommandRouter(
    private val ctx: Context,
    private val say: (String) -> Unit,
    private val stopAssistant: () -> Unit,
    private val ai: (String) -> Unit
) {
    /** Agar Nova ne koi sawal poocha hai to agla jawab yahan aata hai. */
    var awaiting: ((String) -> Unit)? = null

    private val main = Handler(Looper.getMainLooper())

    private fun nm(): String = Cfg.userName(ctx)

    private val filler = setOf(
        "karo", "kar", "do", "de", "dena", "please", "plz", "zara", "mujhe", "mere", "liye", "ko", "ka", "ki", "ke",
        "se", "par", "pe", "per", "ji", "nova", "app", "and", "aur", "the", "a", "to", "ek", "zara",
        "kholo", "khol", "open", "launch", "start",
        "पर", "को", "का", "की", "के", "से", "करो", "कर", "दो", "दीजिये", "जरा", "ज़रा", "मुझे", "मेरे", "लिए",
        "प्लीज", "खोलो", "खोल", "ओपन", "ऐप", "एप", "जी", "और", "एक"
    )

    private val wa = listOf(
        "whatsapp", "whats app", "व्हाट्सएप", "व्हाट्सऐप", "वाट्सएप", "वॉट्सऐप", "वॉट्सएप", "व्हाट्स एप", "वाटसएप"
    )

    private val msgWords = setOf(
        "message", "msg", "मैसेज", "संदेश", "bhejo", "bhej", "भेजो", "भेज", "send", "likho", "likh", "लिखो", "लिख",
        "text", "sms", "bolo", "बोलो"
    )

    private val appAlias: Map<String, List<String>> = mapOf(
        "whatsapp" to wa,
        "youtube" to listOf("youtube", "you tube", "यूट्यूब", "यू ट्यूब", "यूटूब"),
        "instagram" to listOf("instagram", "insta", "इंस्टाग्राम", "इंस्टा"),
        "chrome" to listOf("chrome", "क्रोम"),
        "camera" to listOf("camera", "कैमरा"),
        "photos" to listOf("photos", "gallery", "फोटो", "फ़ोटो", "गैलरी"),
        "settings" to listOf("settings", "setting", "सेटिंग", "सेटिंग्स"),
        "maps" to listOf("maps", "map", "मैप", "मैप्स"),
        "gmail" to listOf("gmail", "जीमेल"),
        "phonepe" to listOf("phonepe", "phone pe", "फोनपे", "फोन पे"),
        "paytm" to listOf("paytm", "पेटीएम"),
        "spotify" to listOf("spotify", "स्पॉटिफाई"),
        "telegram" to listOf("telegram", "टेलीग्राम"),
        "snapchat" to listOf("snapchat", "स्नैपचैट"),
        "facebook" to listOf("facebook", "फेसबुक"),
        "calculator" to listOf("calculator", "कैलकुलेटर"),
        "clock" to listOf("clock", "घड़ी", "क्लॉक"),
        "contacts" to listOf("contacts", "contact", "कॉन्टैक्ट", "संपर्क"),
        "play store" to listOf("play store", "playstore", "प्ले स्टोर"),
        "google pay" to listOf("google pay", "gpay", "जीपे", "गूगल पे")
    )

    // ======================================================================
    //  Mukhya function
    // ======================================================================

    fun handle(raw: String) {
        val pending = awaiting
        if (pending != null) {
            awaiting = null
            pending(raw.trim())
            return
        }
        val t = raw.lowercase(Locale.ROOT)
            .replace(Regex("[?.!,।\"']"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        val words = t.split(" ")

        fun w(vararg x: String) = x.any { it in words }
        fun h(vararg x: String) = x.any { t.contains(it) }

        if (t.isEmpty()) {
            say(if (nm().isEmpty()) "Ji, boliye." else "Ji ${nm()}, boliye.")
            return
        }

        // ---- user ka naam ----
        if (h("mera naam kya", "mera name kya", "मेरा नाम क्या", "main kaun hoon", "मैं कौन हूं", "मैं कौन हूँ", "who am i")) {
            if (nm().isEmpty()) say("Mujhe abhi aapka naam nahi pata. Bolkar bata dijiye, jaise, mera naam Rahul hai.")
            else say("Aapka naam ${nm()} hai.")
            return
        }
        val r1 = Regex("(?:mera naam|mera name|my name is|मेरा नाम)\\s+(.+?)\\s+(?:hai|है)\\s*$").find(t)
        val r2 = Regex("(?:mujhe|मुझे|call me)\\s+(.+?)\\s*(?:naam se bulao|naam se bulana|नाम से बुलाओ|नाम से बुलाना|kehkar bulao|कहकर बुलाओ)\\s*$").find(t)
            ?: Regex("^call me\\s+(.+)$").find(t)
        val newName = (r1 ?: r2)?.groupValues?.get(1)?.trim()
        if (newName != null && newName.isNotEmpty() && newName.split(" ").size <= 3 &&
            newName !in setOf("ye", "yeh", "kya", "kaun", "kaise", "यह", "ये", "क्या", "कौन")
        ) {
            val pretty = newName.split(" ").joinToString(" ") { w -> w.replaceFirstChar { c -> c.uppercase() } }
            Cfg.setUserName(ctx, pretty)
            say("Theek hai $pretty, ab main aapko isi naam se bulaunga.")
            return
        }

        // ---- awaaz badalna ----
        if (h("voice badlo", "voice change", "change voice", "next voice", "awaaz badlo", "aawaz badlo", "आवाज बदलो", "आवाज़ बदलो", "आवाज़ बदल", "आवाज बदल", "वॉइस बदलो", "वॉयस बदलो", "dusri awaaz", "दूसरी आवाज")) {
            switchVoice(t)
            return
        }

        if (h("band ho jao", "band ho ja", "so jao", "stop listening", "बंद हो जाओ", "सो जाओ")) {
            say("Theek hai, main band ho raha hoon. Phir milte hain.")
            main.postDelayed({ stopAssistant() }, 3500)
            return
        }

        if (h("kaun ho", "kon ho", "who are you", "tum kaun", "तुम कौन", "आप कौन", "your name", "तेरा नाम", "तुम्हारा नाम")) {
            say("Main Nova hoon, aapka voice assistant. Bas bolkar phone chalaiye ya mujhse kuch bhi poochhiye.")
            return
        }

        if (words.size <= 2 && w("hello", "hi", "hey", "namaste", "हेलो", "नमस्ते", "हाय", "hello")) {
            say(if (nm().isEmpty()) "Namaste! Bataiye, kya karun?" else "Namaste ${nm()}! Bataiye, kya karun?")
            return
        }

        // ---- phone call uthana / kaatna ----
        if (h("call utha", "phone utha", "call uthao", "फोन उठा", "कॉल उठा", "call receive", "answer call", "pick up")) {
            answerCall()
            return
        }
        if (h("call kaat", "phone kaat", "call kat", "कॉल काट", "फोन काट", "end call", "disconnect", "call cut")) {
            endCall()
            return
        }

        // ---- alarm / timer ----
        if (h("alarm", "अलार्म")) {
            setAlarm(t)
            return
        }
        if (h("timer", "टाइमर")) {
            setTimer(t)
            return
        }

        // ---- samay, tarikh, battery ----
        if (h("kitne baje", "कितने बजे", "समय क्या", "samay kya") || (w("time", "टाइम") && words.size <= 4)) {
            sayTime()
            return
        }
        if ((w("date") && words.size <= 4) || h("tarikh", "tareekh", "तारीख", "तारीक", "kaun sa din", "कौन सा दिन")) {
            sayDate()
            return
        }
        if (h("battery", "बैटरी")) {
            sayBattery()
            return
        }

        // ---- torch ----
        if (h("torch", "flashlight", "flash light", "टॉर्च", "टार्च", "फ्लैश")) {
            val off = h("band", "off", "bujha", "बंद", "बुझा", "बन्द")
            torch(!off)
            return
        }

        // ---- volume ----
        if (h("volume", "awaaz", "आवाज", "वॉल्यूम", "वोल्यूम") || w("mute", "म्यूट")) {
            volume(t)
            return
        }

        // ---- phone control (accessibility) ----
        if (h("scroll", "स्क्रोल", "swipe", "स्वाइप", "agli reel", "next reel", "अगली रील", "next short", "next video", "अगला वीडियो")) {
            scroll(t)
            return
        }
        if (h("screenshot", "स्क्रीनशॉट", "स्क्रीन शॉट")) {
            global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, 28, "Screenshot le liya.")
            return
        }
        if ((w("back") && words.size <= 3) || h("peeche jao", "piche jao", "पीछे जाओ", "वापस जाओ", "vapas jao")) {
            global(AccessibilityService.GLOBAL_ACTION_BACK, 0, "Peeche aa gaya.")
            return
        }
        if ((w("home") && words.size <= 3) || h("home screen", "होम स्क्रीन", "होम पर")) {
            global(AccessibilityService.GLOBAL_ACTION_HOME, 0, "Home screen par hoon.")
            return
        }
        if (h("recent", "रिसेंट")) {
            global(AccessibilityService.GLOBAL_ACTION_RECENTS, 0, "Recent apps khol diye.")
            return
        }
        if (h("notification", "नोटिफिकेशन", "नोटिफ़िकेशन")) {
            global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, 0, "Notifications khol diye.")
            return
        }
        if (h("quick settings", "क्विक सेटिंग")) {
            global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS, 0, "Quick settings khol di.")
            return
        }
        if ((w("lock") && words.size <= 3) || h("screen lock", "screen band", "स्क्रीन बंद", "लॉक")) {
            global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, 28, "Screen lock kar di.")
            return
        }
        if (w("click", "tap", "press") || h("क्लिक", "दबाओ", "टैप")) {
            val label = strip(t, setOf("click", "tap", "press", "क्लिक", "दबाओ", "टैप", "on", "button", "बटन"))
            clickLabel(label)
            return
        }

        // ---- message / call ----
        val waMention = wa.any { t.contains(it) }
        val isMsg = h("message", "msg", "मैसेज", "संदेश")
        val isCall = h("call", "कॉल", "dial", "lagao", "लगाओ", "phone kar", "फोन कर", "phone laga", "फोन लगा")
        if (isMsg && (waMention || h("bhej", "भेज", "send", "likh", "लिख"))) {
            whatsappMessage(t)
            return
        }
        if (isCall) {
            if (waMention) whatsappCall(dropAndStrip(t, setOf("call", "कॉल", "voice", "video", "dial", "lagao", "लगाओ", "laga", "लगा", "phone", "फोन", "फ़ोन")))
            else normalCall(dropAndStrip(t, setOf("call", "कॉल", "dial", "lagao", "लगाओ", "laga", "लगा", "phone", "फोन", "फ़ोन")))
            return
        }

        // ---- Settings shortcuts ----
        if (h("wifi", "wi-fi", "wi fi", "वाईफाई", "वाइफाई", "वाई फाई", "वाई-फाई", "internet", "इंटरनेट")) {
            openSettingsPanel(wifi = true)
            return
        }
        if (h("bluetooth", "ब्लूटूथ")) {
            openSettings(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth ki settings khol di.")
            return
        }
        if (h("brightness", "ब्राइटनेस")) {
            openSettings(Settings.ACTION_DISPLAY_SETTINGS, "Display aur brightness ki settings khol di.")
            return
        }
        if (h("location", "लोकेशन")) {
            openSettings(Settings.ACTION_LOCATION_SOURCE_SETTINGS, "Location ki settings khol di.")
            return
        }
        if (h("airplane", "flight mode", "फ्लाइट मोड", "एयरप्लेन")) {
            openSettings(Settings.ACTION_AIRPLANE_MODE_SETTINGS, "Flight mode ki settings khol di.")
            return
        }

        // ---- YouTube, maps, camera, search ----
        if (h("youtube", "यूट्यूब", "यू ट्यूब", "यूटूब")) {
            val aliasList = appAlias["youtube"] ?: emptyList()
            val q = dropAndStrip(
                t,
                setOf("search", "dhundo", "chalao", "play", "सर्च", "ढूंढो", "चलाओ", "चला", "बजाओ", "bajao", "video", "वीडियो", "gana", "gaana", "गाना"),
                aliasList
            )
            if (q.isEmpty()) {
                if (!launchApp("youtube")) say("YouTube app nahi mila.") else say("YouTube khol raha hoon.")
            } else {
                val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
                if (installed("com.google.android.youtube")) i.setPackage("com.google.android.youtube")
                say("YouTube par $q dhundh raha hoon.")
                start(i)
            }
            return
        }
        if (h("navigate", "navigation", "directions", "rasta", "रास्ता", "नेविगेट", "नेविगेशन", "le chalo", "ले चलो")) {
            val dest = strip(t, setOf("navigate", "navigation", "directions", "rasta", "रास्ता", "नेविगेट", "नेविगेशन", "le", "chalo", "ले", "चलो", "tak", "तक", "jana", "जाना", "hai", "है", "batao", "बताओ", "map", "maps", "मैप"))
            if (dest.isEmpty()) {
                say("Kahan jana hai?")
                awaiting = { navigate(it) }
            } else navigate(dest)
            return
        }
        if (h("selfie", "सेल्फी")) {
            val i = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            i.putExtra("android.intent.extras.CAMERA_FACING", 1)
            say("Selfie camera khol raha hoon.")
            start(i)
            return
        }
        if (h("camera", "कैमरा", "photo kheench", "फोटो खींच")) {
            say("Camera khol raha hoon.")
            start(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))
            return
        }
        if (h("mausam", "weather", "मौसम")) {
            webSearch("aaj ka mausam")
            return
        }
        if (h("search", "dhundo", "dhoondo", "khojo", "सर्च", "ढूंढो", "ढूँढो", "खोजो")) {
            val q = strip(t, setOf("search", "dhundo", "dhoondo", "khojo", "google", "सर्च", "ढूंढो", "ढूँढो", "खोजो", "गूगल", "web", "internet", "पर"))
            if (q.isEmpty()) {
                say("Kya search karna hai?")
                awaiting = { webSearch(it) }
            } else webSearch(q)
            return
        }

        // ---- app kholna ----
        if (w("open", "launch", "start") || h("kholo", "khol do", "खोलो", "खोल दो", "ओपन")) {
            val name = strip(t)
            if (name.isNotEmpty() && launchApp(name)) {
                say("$name khol raha hoon.")
                return
            }
            if (name.isNotEmpty()) {
                say("$name naam ka app mujhe nahi mila.")
                return
            }
        }

        // ---- music ----
        if ((w("next") && words.size <= 4) || h("agla", "अगला", "अगले")) {
            media(KeyEvent.KEYCODE_MEDIA_NEXT, "Agla gaana.")
            return
        }
        if ((w("previous") && words.size <= 4) || h("pichla", "पिछला", "पिछले")) {
            media(KeyEvent.KEYCODE_MEDIA_PREVIOUS, "Pichla gaana.")
            return
        }
        if ((w("pause", "stop") && words.size <= 4) || h("ruko", "रुको", "roko", "रोको")) {
            media(KeyEvent.KEYCODE_MEDIA_PAUSE, "Ruk gaya.")
            return
        }
        if ((w("play", "resume") && words.size <= 4) || h("chalao", "चलाओ", "bajao", "बजाओ", "gaana", "गाना", "गाने")) {
            media(KeyEvent.KEYCODE_MEDIA_PLAY, "Gaana chala raha hoon.")
            return
        }

        ai(raw)
    }

    private fun switchVoice(t: String) {
        val list = Cfg.voices(ctx)
        if (list.isEmpty() || Cfg.elKey(ctx).isEmpty()) {
            say("Abhi sirf phone ki awaaz hai. App mein VOICES se ElevenLabs ki awaazein joDiye.")
            return
        }
        // naam se: "awaaz badlo sara"
        var pick = -1
        for ((i, v) in list.withIndex()) {
            if (v.name.isNotBlank() && t.contains(v.name.lowercase(Locale.ROOT))) pick = i
        }
        val num = Regex("(\\d+)").find(t)?.groupValues?.get(1)?.toIntOrNull()
        if (pick < 0 && num != null && num in 1..list.size) pick = num - 1
        if (pick < 0) {
            val cur = Cfg.activeIndex(ctx)
            pick = if (cur + 1 < list.size) cur + 1 else 0
        }
        Cfg.setActiveIndex(ctx, pick)
        say("Ye meri nayi awaaz hai, ${list[pick].name}.")
    }

    // ======================================================================
    //  Chhote helper
    // ======================================================================

    private fun strip(t: String, extra: Set<String> = emptySet()): String =
        t.split(" ").filter { it.isNotEmpty() && it !in filler && it !in extra }.joinToString(" ").trim()

    private fun dropPhrases(t: String, list: List<String>): String {
        var s = t
        for (p in list) s = s.replace(p, " ")
        return s.replace(Regex("\\s+"), " ").trim()
    }

    private fun dropAndStrip(t: String, extra: Set<String>, phrases: List<String> = wa): String =
        strip(dropPhrases(t, phrases), extra)

    private fun start(i: Intent): Boolean {
        return try {
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            val c: Context = NovaAccessibility.instance ?: ctx
            c.startActivity(i)
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun installed(pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (e: Exception) {
        false
    }

    private fun audio(): AudioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    private fun hasPerm(p: String): Boolean = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    private fun a11y(): NovaAccessibility? {
        val a = NovaAccessibility.instance
        if (a == null) {
            say("Iske liye Accessibility permission chalu karni hogi. Nova app mein ACCESS button dabayein.")
        }
        return a
    }

    private fun global(action: Int, minSdk: Int, reply: String) {
        if (Build.VERSION.SDK_INT < minSdk) {
            say("Ye aapke Android version par nahi chalta.")
            return
        }
        val a = a11y() ?: return
        if (a.global(action)) say(reply) else say("Ye kaam nahi ho paya.")
    }

    private fun tapLater(delay: Long, exact: Boolean, vararg labels: String) {
        main.postDelayed({ NovaAccessibility.instance?.clickByText(exact, *labels) }, delay)
    }

    // ======================================================================
    //  Kaam
    // ======================================================================

    private fun sayTime() {
        val c = Calendar.getInstance()
        var h = c.get(Calendar.HOUR)
        if (h == 0) h = 12
        val m = c.get(Calendar.MINUTE)
        val part = when (c.get(Calendar.HOUR_OF_DAY)) {
            in 4..11 -> "subah"
            in 12..15 -> "dopahar"
            in 16..19 -> "shaam"
            else -> "raat"
        }
        say("Abhi $part ke $h baj kar $m minute hue hain.")
    }

    private fun sayDate() {
        val c = Calendar.getInstance()
        val days = arrayOf("Ravivaar", "Somvaar", "Mangalvaar", "Budhvaar", "Guruvaar", "Shukravaar", "Shanivaar")
        val months = arrayOf(
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        )
        say("Aaj ${days[c.get(Calendar.DAY_OF_WEEK) - 1]} hai, ${c.get(Calendar.DAY_OF_MONTH)} ${months[c.get(Calendar.MONTH)]} ${c.get(Calendar.YEAR)}.")
    }

    private fun sayBattery() {
        try {
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
            say("Battery $pct percent hai.")
        } catch (e: Exception) {
            say("Battery ka pata nahi chal paya.")
        }
    }

    private fun torch(on: Boolean) {
        try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            var id: String? = null
            for (cid in cm.cameraIdList) {
                val flash = cm.getCameraCharacteristics(cid).get(CameraCharacteristics.FLASH_INFO_AVAILABLE)
                if (flash == true) {
                    id = cid
                    break
                }
            }
            if (id == null) {
                say("Is phone mein flash nahi mila.")
                return
            }
            cm.setTorchMode(id, on)
            say(if (on) "Torch chalu kar di." else "Torch band kar di.")
        } catch (e: Exception) {
            say("Torch nahi chal payi.")
        }
    }

    private fun volume(t: String) {
        val a = audio()
        val max = a.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        fun hh(vararg x: String) = x.any { t.contains(it) }
        val words = t.split(" ")
        when {
            hh("full", "max", "poora", "पूरा", "फुल") -> {
                a.setStreamVolume(AudioManager.STREAM_MUSIC, max, 0)
                say("Volume full kar diya.")
            }
            hh("mute", "zero", "म्यूट", "band", "बंद", "silent", "साइलेंट") -> {
                a.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
                say("Volume band kar diya.")
            }
            "up" in words || hh("badha", "increase", "zyada", "jyada", "ज्यादा", "बढ़ा", "बढा", "tez", "तेज") -> {
                for (n in 1..3) a.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                say("Volume badha diya.")
            }
            "down" in words || hh("kam", "ghata", "decrease", "कम", "घटा", "धीमी", "dheemi") -> {
                for (n in 1..3) a.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                say("Volume kam kar diya.")
            }
            else -> say("Volume badhana hai ya kam karna hai?")
        }
    }

    private fun media(code: Int, reply: String) {
        val a = audio()
        a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        a.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
        say(reply)
    }

    private fun openSettings(action: String, reply: String) {
        say("$reply Android khud se on off nahi karne deta, aap ek tap se kar lein.")
        start(Intent(action))
    }

    private fun openSettingsPanel(wifi: Boolean) {
        say("Internet ke toggles khol raha hoon. Android khud se on off nahi karne deta, aap ek tap se kar lein.")
        if (wifi && Build.VERSION.SDK_INT >= 29) {
            start(Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY))
        } else {
            start(Intent(Settings.ACTION_WIFI_SETTINGS))
        }
    }

    private fun webSearch(q: String) {
        say("$q search kar raha hoon.")
        val i = Intent(Intent.ACTION_WEB_SEARCH)
        i.putExtra(SearchManager.QUERY, q)
        if (!start(i)) {
            start(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
        }
    }

    private fun navigate(dest: String) {
        say("$dest ka rasta khol raha hoon.")
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(dest)))
        if (installed("com.google.android.apps.maps")) i.setPackage("com.google.android.apps.maps")
        start(i)
    }

    private fun scroll(t: String) {
        val a = a11y() ?: return
        val dm = ctx.resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()
        val up = t.contains("upar") || t.contains("ऊपर") || t.contains(" up")
        val reel = t.contains("reel") || t.contains("रील") || t.contains("short") || t.contains("video") || t.contains("वीडियो")
        if (up && !reel) {
            a.swipe(w / 2f, h * 0.3f, w / 2f, h * 0.7f)
            say("Upar scroll kiya.")
        } else {
            a.swipe(w / 2f, h * 0.72f, w / 2f, h * 0.28f)
            say(if (reel) "Agla video." else "Neeche scroll kiya.")
        }
    }

    private fun clickLabel(label: String) {
        if (label.isEmpty()) {
            say("Kis par tap karna hai?")
            awaiting = { clickLabel(it.lowercase(Locale.ROOT)) }
            return
        }
        val a = a11y() ?: return
        if (a.clickByText(false, label)) say("$label daba diya.")
        else say("Screen par $label nahi dikha.")
    }

    private fun answerCall() {
        try {
            if (!hasPerm(Manifest.permission.ANSWER_PHONE_CALLS)) {
                say("Call uthane ki permission chahiye.")
                return
            }
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.acceptRingingCall()
            say("Call utha liya.")
        } catch (e: Exception) {
            say("Call nahi utha paya.")
        }
    }

    @Suppress("DEPRECATION")
    private fun endCall() {
        try {
            if (Build.VERSION.SDK_INT < 28 || !hasPerm(Manifest.permission.ANSWER_PHONE_CALLS)) {
                say("Call kaatne ki permission chahiye.")
                return
            }
            val tm = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager
            tm.endCall()
            say("Call kaat diya.")
        } catch (e: Exception) {
            say("Call nahi kaat paya.")
        }
    }

    private fun setAlarm(t: String) {
        val m = Regex("(\\d{1,2})(?:\\s*[:.]\\s*(\\d{2}))?").find(t)
        if (m == null) {
            say("Kitne baje ka alarm lagana hai?")
            awaiting = { setAlarm("alarm " + it.lowercase(Locale.ROOT)) }
            return
        }
        var hour = m.groupValues[1].toInt()
        var min = if (m.groupValues[2].isNotEmpty()) m.groupValues[2].toInt() else 0
        if (t.contains("saade") || t.contains("sade") || t.contains("साढ़े") || t.contains("साढे")) min = 30
        if (t.contains("sawa") || t.contains("सवा")) min = 15
        if (t.contains("paune") || t.contains("पौने")) {
            hour -= 1
            min = 45
        }
        val night = t.contains("raat") || t.contains("रात")
        val pm = night || listOf("shaam", "sham", "शाम", "dopahar", "दोपहर", "pm", "p.m").any { t.contains(it) }
        if (pm && hour < 12) hour += 12
        if (night && hour == 12) hour = 0
        if (hour == 12 && (t.contains("subah") || t.contains("सुबह"))) hour = 0
        if (hour !in 0..23 || min !in 0..59) {
            say("Samay samajh nahi aaya.")
            return
        }
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
        i.putExtra(AlarmClock.EXTRA_HOUR, hour)
        i.putExtra(AlarmClock.EXTRA_MINUTES, min)
        i.putExtra(AlarmClock.EXTRA_MESSAGE, "Nova")
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (start(i)) say("$hour baj kar $min minute ka alarm laga diya.") else say("Alarm nahi laga paya.")
    }

    private fun setTimer(t: String) {
        val m = Regex("(\\d+)\\s*(minute|min|मिनट|second|sec|सेकंड|सेकेंड|घंटे|घंटा|ghante|ghanta|hour)").find(t)
        if (m == null) {
            say("Kitne minute ka timer lagana hai?")
            awaiting = { setTimer("timer " + it.lowercase(Locale.ROOT)) }
            return
        }
        val n = m.groupValues[1].toInt()
        val u = m.groupValues[2]
        val secs = when {
            u.startsWith("sec") || u.startsWith("सेक") -> n
            u.startsWith("min") || u == "मिनट" -> n * 60
            else -> n * 3600
        }
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
        i.putExtra(AlarmClock.EXTRA_LENGTH, secs)
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        if (start(i)) say("Timer laga diya.") else say("Timer nahi laga paya.")
    }

    // ======================================================================
    //  Apps
    // ======================================================================

    private fun launchApp(spoken: String): Boolean {
        var key = spoken
        for ((k, vs) in appAlias) {
            if (vs.any { spoken.contains(it) }) {
                key = k
                break
            }
        }
        key = key.lowercase(Locale.ROOT).trim()
        if (key.isEmpty()) return false
        if (key == "settings") return start(Intent(Settings.ACTION_SETTINGS))
        val pm = ctx.packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps: List<ResolveInfo> = pm.queryIntentActivities(q, 0)
        var best: ResolveInfo? = null
        for (a in apps) {
            val label = a.loadLabel(pm).toString().lowercase(Locale.ROOT)
            if (label == key) {
                best = a
                break
            }
            if (best == null && label.contains(key)) best = a
        }
        val found = best ?: return false
        val launch = pm.getLaunchIntentForPackage(found.activityInfo.packageName) ?: return false
        return start(launch)
    }

    // ======================================================================
    //  Contacts, call, WhatsApp
    // ======================================================================

    private class Row(val name: String, val value: String)

    private fun rows(uri: Uri, nameCol: String, valCol: String, sel: String?, args: Array<String>?): List<Row> {
        val out = ArrayList<Row>()
        try {
            ctx.contentResolver.query(uri, arrayOf(nameCol, valCol), sel, args, null)?.use { c ->
                while (c.moveToNext()) {
                    val n = c.getString(0) ?: continue
                    val v = c.getString(1) ?: continue
                    out.add(Row(n, v))
                }
            }
        } catch (e: Exception) {
        }
        return out
    }

    private val dev: Map<Char, String> = mapOf(
        'अ' to "a", 'आ' to "a", 'इ' to "i", 'ई' to "i", 'उ' to "u", 'ऊ' to "u", 'ए' to "e", 'ऐ' to "e",
        'ओ' to "o", 'औ' to "o", 'ऑ' to "o",
        'क' to "k", 'ख' to "k", 'ग' to "g", 'घ' to "g", 'ङ' to "n",
        'च' to "ch", 'छ' to "ch", 'ज' to "j", 'झ' to "j", 'ञ' to "n",
        'ट' to "t", 'ठ' to "t", 'ड' to "d", 'ढ' to "d", 'ण' to "n",
        'त' to "t", 'थ' to "t", 'द' to "d", 'ध' to "d", 'न' to "n",
        'प' to "p", 'फ' to "f", 'ब' to "b", 'भ' to "b", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh", 'ष' to "sh", 'स' to "s", 'ह' to "h",
        'ा' to "a", 'ि' to "i", 'ी' to "i", 'ु' to "u", 'ू' to "u", 'े' to "e", 'ै' to "e", 'ो' to "o", 'ौ' to "o", 'ॉ' to "o",
        'ं' to "", 'ँ' to "", 'ः' to "", '्' to "", '़' to ""
    )

    /** Naam ka "dhwani dhaancha": Hindi aur English ka same naam ek jaisa dikhe. */
    private fun skel(s0: String): String {
        val sb = StringBuilder()
        for (ch in s0.lowercase(Locale.ROOT)) sb.append(dev[ch] ?: ch.toString())
        var s = sb.toString()
        val pairs = listOf(
            "ch" to "C", "sh" to "S", "th" to "t", "kh" to "k", "gh" to "g",
            "bh" to "b", "dh" to "d", "ph" to "f", "jh" to "j"
        )
        for ((a, b) in pairs) s = s.replace(a, b)
        val out = StringBuilder()
        for (ch in s) {
            val m = when (ch) {
                'a', 'e', 'i', 'o', 'u', 'h', 'y', ' ', '-', '.' -> ""
                'c', 'q' -> "k"
                'w' -> "v"
                'z' -> "j"
                'x' -> "ks"
                else -> if (ch.isLetter()) ch.toString() else ""
            }
            out.append(m)
        }
        val r = StringBuilder()
        for (ch in out) {
            if (r.isEmpty() || r[r.length - 1] != ch) r.append(ch)
        }
        return r.toString()
    }

    private fun nameVariants(n: String): List<String> {
        val groups = listOf(
            listOf("mummy", "mom", "mama", "maa", "mother", "मम्मी", "माँ", "मां", "मॉम"),
            listOf("papa", "pappa", "dad", "father", "पापा", "डैड"),
            listOf("bhai", "bro", "भाई"),
            listOf("didi", "sister", "दीदी")
        )
        for (g in groups) if (n in g) return g
        return listOf(n)
    }

    private fun score(contact: String, spoken: String): Int {
        val cl = contact.lowercase(Locale.ROOT)
        val sl = spoken.lowercase(Locale.ROOT).trim()
        if (sl.isEmpty()) return 0
        if (cl == sl) return 5
        if (cl.contains(sl)) return 4
        val cs = skel(cl)
        val ss = skel(sl)
        if (ss.isEmpty()) return 0
        if (cs == ss) return 3
        if (ss.length >= 3 && cs.contains(ss)) return 2
        return 0
    }

    private fun pick(list: List<Row>, spoken: String): Row? {
        var best: Row? = null
        var bs = 0
        for (v in nameVariants(spoken)) {
            for (c in list) {
                val s = score(c.name, v)
                if (s > bs) {
                    bs = s
                    best = c
                }
            }
        }
        return best
    }

    private fun phoneRows(): List<Row> = rows(
        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
        ContactsContract.Contacts.DISPLAY_NAME,
        ContactsContract.CommonDataKinds.Phone.NUMBER,
        null, null
    )

    private fun normalizeNumber(n: String): String {
        val d = n.filter { it.isDigit() }
        return when {
            d.length == 10 -> "91$d"
            d.length == 11 && d.startsWith("0") -> "91" + d.substring(1)
            else -> d
        }
    }

    private fun normalCall(name: String) {
        if (name.isEmpty()) {
            say("Kisko call karna hai?")
            awaiting = { normalCall(strip(it.lowercase(Locale.ROOT))) }
            return
        }
        val digits = name.filter { it.isDigit() }
        val number: String
        if (digits.length >= 6) {
            number = digits
            say("Is number par call laga raha hoon.")
        } else {
            if (!hasPerm(Manifest.permission.READ_CONTACTS)) {
                say("Contacts ki permission chahiye. Nova app mein PERMS dabayein.")
                return
            }
            val c = pick(phoneRows(), name)
            if (c == null) {
                say("$name naam ka contact nahi mila.")
                return
            }
            number = c.value
            say("${c.name} ko call laga raha hoon.")
        }
        val uri = Uri.parse("tel:" + Uri.encode(number))
        if (hasPerm(Manifest.permission.CALL_PHONE)) start(Intent(Intent.ACTION_CALL, uri)) else start(Intent(Intent.ACTION_DIAL, uri))
    }

    private fun whatsappCall(name: String) {
        if (name.isEmpty()) {
            say("Kisko WhatsApp call karna hai?")
            awaiting = { whatsappCall(dropAndStrip(it.lowercase(Locale.ROOT), emptySet())) }
            return
        }
        if (!hasPerm(Manifest.permission.READ_CONTACTS)) {
            say("Contacts ki permission chahiye. Nova app mein PERMS dabayein.")
            return
        }
        val variants = listOf(
            Pair("com.whatsapp", "vnd.android.cursor.item/vnd.com.whatsapp.voip.call"),
            Pair("com.whatsapp.w4b", "vnd.android.cursor.item/vnd.com.whatsapp.w4b.voip.call")
        )
        for ((pkg, mime) in variants) {
            val list = rows(
                ContactsContract.Data.CONTENT_URI,
                ContactsContract.Contacts.DISPLAY_NAME,
                ContactsContract.Data._ID,
                ContactsContract.Data.MIMETYPE + "=?",
                arrayOf(mime)
            )
            val c = pick(list, name) ?: continue
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(Uri.parse("content://com.android.contacts/data/" + c.value), mime)
            i.setPackage(pkg)
            say("${c.name} ko WhatsApp par call laga raha hoon.")
            if (start(i)) {
                tapLater(2500, true, "call", "voice call", "कॉल")
                return
            }
        }
        say("WhatsApp par $name nahi mila.")
    }

    private fun whatsappMessage(t: String) {
        var nameText = t
        var body: String? = null
        val m = Regex("^(.*?)\\s(?:ki|कि|that|bolo|बोलो)\\s(.+)$").find(t)
        if (m != null) {
            nameText = m.groupValues[1]
            body = m.groupValues[2]
        }
        val name = dropAndStrip(nameText, msgWords)
        if (name.isEmpty()) {
            say("Kisko message bhejna hai?")
            awaiting = { whatsappMessage(it.lowercase(Locale.ROOT) + " message") }
            return
        }
        if (!hasPerm(Manifest.permission.READ_CONTACTS)) {
            say("Contacts ki permission chahiye. Nova app mein PERMS dabayein.")
            return
        }
        val c = pick(phoneRows(), name)
        if (c == null) {
            say("$name naam ka contact nahi mila.")
            return
        }
        val bd = body
        if (bd == null || bd.isBlank()) {
            say("${c.name} ko kya message bhejna hai?")
            awaiting = { b -> sendWhatsapp(c.name, c.value, b) }
        } else {
            sendWhatsapp(c.name, c.value, bd)
        }
    }

    private fun sendWhatsapp(name: String, number: String, body: String) {
        val num = normalizeNumber(number)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + num + "?text=" + Uri.encode(body)))
        if (installed("com.whatsapp")) i.setPackage("com.whatsapp")
        else if (installed("com.whatsapp.w4b")) i.setPackage("com.whatsapp.w4b")
        say("$name ko message bhej raha hoon.")
        if (start(i)) {
            tapLater(3200, true, "send", "भेजें")
            tapLater(5200, true, "send", "भेजें")
        }
    }
}
