package com.nova.assistant

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale

/** Nova ki awaazein: ek jagah se chuno, suno, jodo, badlo, hatao. */
class VoicesActivity : Activity() {

    private val cyan = 0xFF00E5FF.toInt()
    private val soft = 0xFF7FE9FF.toInt()
    private val bg = 0xFF020B14.toInt()
    private val mono = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
    private val monoLight = Typeface.MONOSPACE
    private val ui = Handler(Looper.getMainLooper())

    private var player: MediaPlayer? = null
    private var localTts: TextToSpeech? = null

    private lateinit var list: LinearLayout
    private lateinit var activeLine: TextView
    private lateinit var addBtn: Button

    private fun dp(v: Float): Int = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)

        // upar ki patti
        val head = LinearLayout(this)
        head.orientation = LinearLayout.VERTICAL
        head.setPadding(dp(18f), dp(14f), dp(18f), dp(10f))

        val back = TextView(this)
        back.text = "‹ WAPAS"
        back.typeface = mono
        back.textSize = 12f
        back.setTextColor(soft)
        back.letterSpacing = 0.15f
        back.setPadding(0, dp(6f), dp(20f), dp(10f))
        back.setOnClickListener { finish() }
        head.addView(back)

        val title = TextView(this)
        title.text = "NOVA VOICES"
        title.typeface = mono
        title.textSize = 26f
        title.letterSpacing = 0.25f
        title.setTextColor(cyan)
        head.addView(title)

        val sub = TextView(this)
        sub.text = "Awaaz par tap karke chuniye. Ek se zyada awaazein jod sakte hain."
        sub.typeface = monoLight
        sub.textSize = 12f
        sub.setTextColor(soft)
        sub.setPadding(0, dp(4f), 0, dp(10f))
        head.addView(sub)

        activeLine = TextView(this)
        activeLine.typeface = mono
        activeLine.textSize = 12f
        activeLine.letterSpacing = 0.1f
        activeLine.setTextColor(0xFF020B14.toInt())
        activeLine.setPadding(dp(12f), dp(7f), dp(12f), dp(7f))
        val pill = GradientDrawable()
        pill.setColor(cyan)
        pill.cornerRadius = dp(6f).toFloat()
        activeLine.background = pill
        head.addView(
            activeLine,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        root.addView(head)

        // awaazon ki list
        val scroll = ScrollView(this)
        list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        list.setPadding(dp(14f), dp(4f), dp(14f), dp(14f))
        scroll.addView(
            list,
            ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        root.addView(scroll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // neeche jodne ka button
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.VERTICAL
        bar.setPadding(dp(14f), dp(8f), dp(14f), dp(14f))
        addBtn = Button(this)
        addBtn.typeface = mono
        addBtn.textSize = 14f
        addBtn.setTextColor(0xFF020B14.toInt())
        addBtn.stateListAnimator = null
        val g = GradientDrawable()
        g.setColor(cyan)
        g.cornerRadius = dp(10f).toFloat()
        addBtn.background = g
        addBtn.setOnClickListener { editDialog(-1) }
        bar.addView(addBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(52f)))
        root.addView(bar)

        setContentView(root)
        render()
    }

    override fun onDestroy() {
        stopPlayer()
        try {
            localTts?.stop()
            localTts?.shutdown()
        } catch (e: Exception) {
        }
        localTts = null
        super.onDestroy()
    }

    // ---------- list banana ----------

    private fun mask(id: String): String =
        if (id.length <= 8) id else id.take(4) + "••••" + id.takeLast(4)

    private fun render() {
        list.removeAllViews()
        val voices = Cfg.voices(this)
        val active = Cfg.activeIndex(this)
        val activeName = if (active in voices.indices) voices[active].name else "Phone ki awaaz"
        activeLine.text = "ACTIVE  ›  " + activeName.uppercase(Locale.getDefault())

        list.addView(card(0, "Phone ki awaaz", "Default. Internet nahi chahiye.", active !in voices.indices, -1))
        for ((i, v) in voices.withIndex()) {
            list.addView(card(i + 1, v.name, mask(v.id), i == active, i))
        }
        if (voices.isEmpty()) {
            val tip = TextView(this)
            tip.text = "Abhi koi ElevenLabs awaaz nahi hai.\nNeeche button se apni Voice ID jodiye.\n(ElevenLabs API key PROFILE mein daalni hai.)"
            tip.typeface = monoLight
            tip.textSize = 12f
            tip.setTextColor(soft)
            tip.setPadding(dp(4f), dp(12f), dp(4f), dp(4f))
            list.addView(tip)
        }
        addBtn.text = "+ NAYI AWAAZ JODO  (${voices.size})"
        addBtn.isEnabled = voices.size < 20
        addBtn.alpha = if (voices.size < 20) 1f else 0.4f
    }

    private fun outline(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.typeface = mono
        t.textSize = 11f
        t.letterSpacing = 0.1f
        t.setTextColor(cyan)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(14f), dp(8f), dp(14f), dp(8f))
        val g = GradientDrawable()
        g.setColor(0x1100E5FF)
        g.setStroke(dp(1f), 0xAA00E5FF.toInt())
        g.cornerRadius = dp(6f).toFloat()
        t.background = g
        t.setOnClickListener { onClick() }
        return t
    }

    private fun card(number: Int, name: String, subtitle: String, selected: Boolean, voiceIdx: Int): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.setPadding(dp(14f), dp(14f), dp(14f), dp(12f))
        val g = GradientDrawable()
        g.cornerRadius = dp(12f).toFloat()
        if (selected) {
            g.setColor(0x3300E5FF)
            g.setStroke(dp(2f), cyan)
        } else {
            g.setColor(0x0D00E5FF)
            g.setStroke(dp(1f), 0x6600E5FF)
        }
        c.background = g
        c.setOnClickListener {
            Cfg.setActiveIndex(this, voiceIdx)
            render()
        }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL

        val num = TextView(this)
        num.text = String.format(Locale.US, "%02d", number)
        num.typeface = mono
        num.textSize = 24f
        num.setTextColor(if (selected) cyan else 0x8800E5FF.toInt())
        num.setPadding(0, 0, dp(14f), 0)
        row.addView(num)

        val mid = LinearLayout(this)
        mid.orientation = LinearLayout.VERTICAL
        val n = TextView(this)
        n.text = name
        n.typeface = mono
        n.textSize = 17f
        n.setTextColor(0xFFFFFFFF.toInt())
        n.maxLines = 1
        n.ellipsize = android.text.TextUtils.TruncateAt.END
        mid.addView(n)
        val s = TextView(this)
        s.text = subtitle
        s.typeface = monoLight
        s.textSize = 11f
        s.setTextColor(soft)
        s.maxLines = 1
        mid.addView(s)
        row.addView(mid, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        if (selected) {
            val chip = TextView(this)
            chip.text = "ACTIVE"
            chip.typeface = mono
            chip.textSize = 10f
            chip.letterSpacing = 0.12f
            chip.setTextColor(0xFF020B14.toInt())
            chip.setPadding(dp(8f), dp(4f), dp(8f), dp(4f))
            val cg = GradientDrawable()
            cg.setColor(cyan)
            cg.cornerRadius = dp(5f).toFloat()
            chip.background = cg
            row.addView(chip)
        }
        c.addView(row)

        val actions = LinearLayout(this)
        actions.orientation = LinearLayout.HORIZONTAL
        actions.setPadding(0, dp(10f), 0, 0)
        actions.addView(outline("▶ SUNO") { preview(voiceIdx) })
        if (voiceIdx >= 0) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.leftMargin = dp(8f)
            actions.addView(outline("EDIT") { editDialog(voiceIdx) }, lp)
            val lp2 = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp2.leftMargin = dp(8f)
            actions.addView(outline("HATAO") { deleteDialog(voiceIdx) }, lp2)
        }
        c.addView(actions)

        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.bottomMargin = dp(10f)
        c.layoutParams = lp
        return c
    }

    // ---------- jodna, badalna, hatana ----------

    private fun editDialog(idx: Int) {
        val voices = Cfg.voices(this)
        val cur = if (idx >= 0 && idx < voices.size) voices[idx] else null

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(20f), dp(8f), dp(20f), 0)

        val nameIn = EditText(this)
        nameIn.hint = "Naam (jaise: Sara, Rahul, Dost)"
        nameIn.setSingleLine(true)
        nameIn.setText(cur?.name ?: "")
        box.addView(nameIn)

        val idIn = EditText(this)
        idIn.hint = "ElevenLabs Voice ID"
        idIn.setSingleLine(true)
        idIn.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        idIn.setText(cur?.id ?: "")
        box.addView(idIn)

        AlertDialog.Builder(this)
            .setTitle(if (cur == null) "Nayi awaaz" else "Awaaz badlo")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                val n = nameIn.text.toString().trim()
                val id = idIn.text.toString().replace(Regex("\\s"), "")
                if (n.isEmpty() || id.isEmpty()) {
                    toast("Naam aur Voice ID dono chahiye.")
                } else {
                    val l = Cfg.voices(this)
                    if (cur == null) {
                        l.add(VoiceItem(n, id))
                        Cfg.saveVoices(this, l)
                        if (l.size == 1) Cfg.setActiveIndex(this, 0)
                    } else if (idx in l.indices) {
                        l[idx] = VoiceItem(n, id)
                        Cfg.saveVoices(this, l)
                    }
                    render()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun deleteDialog(idx: Int) {
        val l = Cfg.voices(this)
        if (idx !in l.indices) return
        AlertDialog.Builder(this)
            .setTitle("Hatayein?")
            .setMessage("\"${l[idx].name}\" list se hat jayegi.")
            .setPositiveButton("Hatao") { _, _ ->
                val cur = Cfg.voices(this)
                if (idx in cur.indices) {
                    cur.removeAt(idx)
                    Cfg.saveVoices(this, cur)
                    val a = Cfg.activeIndex(this)
                    if (a == idx) Cfg.setActiveIndex(this, -1)
                    else if (a > idx) Cfg.setActiveIndex(this, a - 1)
                    render()
                }
            }
            .setNegativeButton("Rehne do", null)
            .show()
    }

    // ---------- sunna ----------

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    }

    private fun preview(idx: Int) {
        stopPlayer()
        val who = Cfg.userName(this)
        val text = if (who.isEmpty()) "Namaste, main Nova hoon. Ye meri awaaz hai."
        else "Namaste $who, main Nova hoon. Ye meri awaaz hai."
        if (idx < 0) {
            localPreview(text)
            return
        }
        val key = Cfg.elKey(this)
        if (key.isEmpty()) {
            toast("Pehle PROFILE mein ElevenLabs API key daaliye.")
            return
        }
        val l = Cfg.voices(this)
        if (idx !in l.indices) return
        val v = l[idx]
        toast("Awaaz bana raha hoon...")
        Thread {
            val r = Eleven.synth(this, text, v.id, key, "preview")
            ui.post {
                val f = r.file
                if (isDestroyed) {
                    f?.delete()
                } else if (f == null) {
                    toast(r.error ?: "Awaaz nahi ban payi.")
                } else {
                    playFile(f)
                }
            }
        }.start()
    }

    private fun localPreview(text: String) {
        val t = localTts
        if (t != null) {
            t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "p")
            return
        }
        localTts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                localTts?.language = Locale("hi", "IN")
                localTts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "p")
            }
        }
    }

    private fun playFile(f: File) {
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener {
                f.delete()
            }
            mp.setOnErrorListener { _, _, _ ->
                f.delete()
                true
            }
            player = mp
            mp.prepareAsync()
        } catch (e: Exception) {
            f.delete()
        }
    }

    private fun stopPlayer() {
        try {
            player?.reset()
        } catch (e: Exception) {
        }
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
    }
}
