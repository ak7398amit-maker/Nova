package com.nova.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

/**
 * Phone ko poori tarah control karne ke liye: back, home, scroll, tap, screenshot, lock.
 * Isse user ko Settings > Accessibility mein ek baar chalu karna padta hai.
 */
class NovaAccessibility : AccessibilityService() {

    companion object {
        @Volatile
        var instance: NovaAccessibility? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    fun global(action: Int): Boolean = performGlobalAction(action)

    fun swipe(fx: Float, fy: Float, tx: Float, ty: Float, durationMs: Long = 350) {
        val path = Path()
        path.moveTo(fx, fy)
        path.lineTo(tx, ty)
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    /** Screen par jis button/text ka naam diya hai use dabata hai. */
    fun clickByText(exact: Boolean, vararg labels: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val wanted = labels.map { it.lowercase(Locale.ROOT) }
        return findAndClick(root, wanted, exact)
    }

    private fun findAndClick(node: AccessibilityNodeInfo?, wanted: List<String>, exact: Boolean): Boolean {
        if (node == null) return false
        val text = node.text?.toString()?.lowercase(Locale.ROOT)
        val desc = node.contentDescription?.toString()?.lowercase(Locale.ROOT)
        var hit = false
        for (w in wanted) {
            if (text != null && (if (exact) text == w else text.contains(w))) hit = true
            if (desc != null && (if (exact) desc == w else desc.contains(w))) hit = true
        }
        if (hit) {
            var c: AccessibilityNodeInfo? = node
            while (c != null && !c.isClickable) {
                c = c.parent
            }
            if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        for (i in 0 until node.childCount) {
            if (findAndClick(node.getChild(i), wanted, exact)) return true
        }
        return false
    }
}
